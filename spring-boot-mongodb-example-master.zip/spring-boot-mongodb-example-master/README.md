# Spring Boot Using Spring Data MongoDB Example

This project depicts the Spring Boot Example with Spring Data MongoDB and REST Example.

